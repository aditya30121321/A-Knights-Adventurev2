extends Node

var score = 0;
@onready var score_label = $ScoreLabel
@onready var restart_dialog: ConfirmationDialog = $"../CanvasLayer/ConfirmationDialog"
func add_point():
	score += 1;
	if score != 40:
		score_label.text = "Coins Collected: " + str(score) + "/40 \n" + " You need: " + str(40 - score) + " Coins"
	else:
		score_label.text = "Victory"	
	
	


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_R:
			if not restart_dialog.visible:
				restart_dialog.popup_centered()
				get_tree().paused = true

func _on_confirmation_dialog_confirmed() -> void:
	get_tree().paused = false
	Engine.time_scale = 1.0
	get_tree().reload_current_scene()

func _on_confirmation_dialog_canceled() -> void:
	get_tree().paused = false
