extends Node2D

const SPEED = 60
const BOUNCE_VELOCITY = -250

var direction = 1
var is_dead = false

@onready var animated_sprite = $AnimatedSprite2D
@onready var ray_cast_right = $RayCastRight
@onready var ray_cast_left = $RayCastLeft
@onready var stomp_area = $StompArea
@onready var killzone = $Killzone

func _process(delta):
	if is_dead:
		return

	if ray_cast_right.is_colliding():
		direction = -1
		animated_sprite.flip_h = true
	if ray_cast_left.is_colliding():
		direction = 1
		animated_sprite.flip_h = false

	position.x += direction * SPEED * delta

func _on_stomp_area_body_entered(body):
	if is_dead:
		return

	if body.name == "Player" and body.velocity.y > 0:
		is_dead = true
		visible = false 
		killzone.set_deferred("monitoring", false)
		stomp_area.set_deferred("monitoring", false)
		body.velocity.y = BOUNCE_VELOCITY
		
		await get_tree().create_timer(4.0).timeout
		
		is_dead = false
		visible = true
		killzone.set_deferred("monitoring", true)
		stomp_area.set_deferred("monitoring", true)
